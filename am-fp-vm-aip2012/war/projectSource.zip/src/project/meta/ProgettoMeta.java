package project.meta;

//@javax.annotation.Generated(value = { "slim3-gen", "@VERSION@" }, date = "2012-06-21 15:55:15")
/** */
public final class ProgettoMeta extends org.slim3.datastore.ModelMeta<project.model.Progetto> {

    /** */
    public final org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, java.lang.Integer> annoFine = new org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, java.lang.Integer>(this, "annoFine", "annoFine", int.class);

    /** */
    public final org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, java.lang.Integer> annoInizio = new org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, java.lang.Integer>(this, "annoInizio", "annoInizio", int.class);

    /** */
    public final org.slim3.datastore.StringUnindexedAttributeMeta<project.model.Progetto> consorzio = new org.slim3.datastore.StringUnindexedAttributeMeta<project.model.Progetto>(this, "consorzio", "consorzio");

    /** */
    public final org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, java.lang.Integer> durata = new org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, java.lang.Integer>(this, "durata", "durata", int.class);

    /** */
    public final org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, com.google.appengine.api.datastore.Key> key = new org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, com.google.appengine.api.datastore.Key>(this, "__key__", "key", com.google.appengine.api.datastore.Key.class);

    /** */
    public final org.slim3.datastore.ModelRefAttributeMeta<project.model.Progetto, org.slim3.datastore.ModelRef<project.model.Partner>, project.model.Partner> leaderRef = new org.slim3.datastore.ModelRefAttributeMeta<project.model.Progetto, org.slim3.datastore.ModelRef<project.model.Partner>, project.model.Partner>(this, "leaderRef", "leaderRef", org.slim3.datastore.ModelRef.class, project.model.Partner.class);

    /** */
    public final org.slim3.datastore.StringUnindexedAttributeMeta<project.model.Progetto> presentazione = new org.slim3.datastore.StringUnindexedAttributeMeta<project.model.Progetto>(this, "presentazione", "presentazione");

    /** */
    public final org.slim3.datastore.StringUnindexedAttributeMeta<project.model.Progetto> risultati = new org.slim3.datastore.StringUnindexedAttributeMeta<project.model.Progetto>(this, "risultati", "risultati");

    /** */
    public final org.slim3.datastore.StringAttributeMeta<project.model.Progetto> tema = new org.slim3.datastore.StringAttributeMeta<project.model.Progetto>(this, "tema", "tema");

    /** */
    public final org.slim3.datastore.StringAttributeMeta<project.model.Progetto> titoloProgetto = new org.slim3.datastore.StringAttributeMeta<project.model.Progetto>(this, "titoloProgetto", "titoloProgetto");

    /** */
    public final org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, java.lang.Long> version = new org.slim3.datastore.CoreAttributeMeta<project.model.Progetto, java.lang.Long>(this, "version", "version", java.lang.Long.class);

    private static final ProgettoMeta slim3_singleton = new ProgettoMeta();

    /**
     * @return the singleton
     */
    public static ProgettoMeta get() {
       return slim3_singleton;
    }

    /** */
    public ProgettoMeta() {
        super("Progetto", project.model.Progetto.class);
    }

    @Override
    public project.model.Progetto entityToModel(com.google.appengine.api.datastore.Entity entity) {
        project.model.Progetto model = new project.model.Progetto();
        model.setAnnoFine(longToPrimitiveInt((java.lang.Long) entity.getProperty("annoFine")));
        model.setAnnoInizio(longToPrimitiveInt((java.lang.Long) entity.getProperty("annoInizio")));
        model.setConsorzio(textToString((com.google.appengine.api.datastore.Text) entity.getProperty("consorzio")));
        model.setDurata(longToPrimitiveInt((java.lang.Long) entity.getProperty("durata")));
        model.setKey(entity.getKey());
        if (model.getLeaderRef() == null) {
            throw new NullPointerException("The property(leaderRef) is null.");
        }
        model.getLeaderRef().setKey((com.google.appengine.api.datastore.Key) entity.getProperty("leaderRef"));
        model.setPresentazione(textToString((com.google.appengine.api.datastore.Text) entity.getProperty("presentazione")));
        model.setRisultati(textToString((com.google.appengine.api.datastore.Text) entity.getProperty("risultati")));
        model.setTema((java.lang.String) entity.getProperty("tema"));
        model.setTitoloProgetto((java.lang.String) entity.getProperty("titoloProgetto"));
        model.setVersion((java.lang.Long) entity.getProperty("version"));
        return model;
    }

    @Override
    public com.google.appengine.api.datastore.Entity modelToEntity(java.lang.Object model) {
        project.model.Progetto m = (project.model.Progetto) model;
        com.google.appengine.api.datastore.Entity entity = null;
        if (m.getKey() != null) {
            entity = new com.google.appengine.api.datastore.Entity(m.getKey());
        } else {
            entity = new com.google.appengine.api.datastore.Entity(kind);
        }
        entity.setProperty("annoFine", m.getAnnoFine());
        entity.setProperty("annoInizio", m.getAnnoInizio());
        entity.setUnindexedProperty("consorzio", stringToText(m.getConsorzio()));
        entity.setProperty("durata", m.getDurata());
        if (m.getLeaderRef() == null) {
            throw new NullPointerException("The property(leaderRef) must not be null.");
        }
        entity.setProperty("leaderRef", m.getLeaderRef().getKey());
        entity.setUnindexedProperty("presentazione", stringToText(m.getPresentazione()));
        entity.setUnindexedProperty("risultati", stringToText(m.getRisultati()));
        entity.setProperty("tema", m.getTema());
        entity.setProperty("titoloProgetto", m.getTitoloProgetto());
        entity.setProperty("version", m.getVersion());
        entity.setProperty("slim3.schemaVersion", 1);
        return entity;
    }

    @Override
    protected com.google.appengine.api.datastore.Key getKey(Object model) {
        project.model.Progetto m = (project.model.Progetto) model;
        return m.getKey();
    }

    @Override
    protected void setKey(Object model, com.google.appengine.api.datastore.Key key) {
        validateKey(key);
        project.model.Progetto m = (project.model.Progetto) model;
        m.setKey(key);
    }

    @Override
    protected long getVersion(Object model) {
        project.model.Progetto m = (project.model.Progetto) model;
        return m.getVersion() != null ? m.getVersion().longValue() : 0L;
    }

    @Override
    protected void assignKeyToModelRefIfNecessary(com.google.appengine.api.datastore.AsyncDatastoreService ds, java.lang.Object model) {
        project.model.Progetto m = (project.model.Progetto) model;
        if (m.getLeaderRef() == null) {
            throw new NullPointerException("The property(leaderRef) must not be null.");
        }
        m.getLeaderRef().assignKeyIfNecessary(ds);
    }

    @Override
    protected void incrementVersion(Object model) {
        project.model.Progetto m = (project.model.Progetto) model;
        long version = m.getVersion() != null ? m.getVersion().longValue() : 0L;
        m.setVersion(Long.valueOf(version + 1L));
    }

    @Override
    protected void prePut(Object model) {
    }

    @Override
    protected void postGet(Object model) {
    }

    @Override
    public String getSchemaVersionName() {
        return "slim3.schemaVersion";
    }

    @Override
    public String getClassHierarchyListName() {
        return "slim3.classHierarchyList";
    }

    @Override
    protected boolean isCipherProperty(String propertyName) {
        return false;
    }

    @Override
    protected void modelToJson(org.slim3.datastore.json.JsonWriter writer, java.lang.Object model, int maxDepth, int currentDepth) {
        project.model.Progetto m = (project.model.Progetto) model;
        writer.beginObject();
        org.slim3.datastore.json.Default encoder0 = new org.slim3.datastore.json.Default();
        writer.setNextPropertyName("annoFine");
        encoder0.encode(writer, m.getAnnoFine());
        writer.setNextPropertyName("annoInizio");
        encoder0.encode(writer, m.getAnnoInizio());
        if(m.getConsorzio() != null){
            writer.setNextPropertyName("consorzio");
            encoder0.encode(writer, m.getConsorzio());
        }
        writer.setNextPropertyName("durata");
        encoder0.encode(writer, m.getDurata());
        if(m.getKey() != null){
            writer.setNextPropertyName("key");
            encoder0.encode(writer, m.getKey());
        }
        if(m.getLeaderRef() != null && m.getLeaderRef().getKey() != null){
            writer.setNextPropertyName("leaderRef");
            encoder0.encode(writer, m.getLeaderRef(), maxDepth, currentDepth);
        }
        if(m.getPresentazione() != null){
            writer.setNextPropertyName("presentazione");
            encoder0.encode(writer, m.getPresentazione());
        }
        if(m.getRisultati() != null){
            writer.setNextPropertyName("risultati");
            encoder0.encode(writer, m.getRisultati());
        }
        if(m.getTema() != null){
            writer.setNextPropertyName("tema");
            encoder0.encode(writer, m.getTema());
        }
        if(m.getTitoloProgetto() != null){
            writer.setNextPropertyName("titoloProgetto");
            encoder0.encode(writer, m.getTitoloProgetto());
        }
        if(m.getVersion() != null){
            writer.setNextPropertyName("version");
            encoder0.encode(writer, m.getVersion());
        }
        writer.endObject();
    }

    @Override
    protected project.model.Progetto jsonToModel(org.slim3.datastore.json.JsonRootReader rootReader, int maxDepth, int currentDepth) {
        project.model.Progetto m = new project.model.Progetto();
        org.slim3.datastore.json.JsonReader reader = null;
        org.slim3.datastore.json.Default decoder0 = new org.slim3.datastore.json.Default();
        reader = rootReader.newObjectReader("annoFine");
        m.setAnnoFine(decoder0.decode(reader, m.getAnnoFine()));
        reader = rootReader.newObjectReader("annoInizio");
        m.setAnnoInizio(decoder0.decode(reader, m.getAnnoInizio()));
        reader = rootReader.newObjectReader("consorzio");
        m.setConsorzio(decoder0.decode(reader, m.getConsorzio()));
        reader = rootReader.newObjectReader("durata");
        m.setDurata(decoder0.decode(reader, m.getDurata()));
        reader = rootReader.newObjectReader("key");
        m.setKey(decoder0.decode(reader, m.getKey()));
        reader = rootReader.newObjectReader("leaderRef");
        decoder0.decode(reader, m.getLeaderRef(), maxDepth, currentDepth);
        reader = rootReader.newObjectReader("presentazione");
        m.setPresentazione(decoder0.decode(reader, m.getPresentazione()));
        reader = rootReader.newObjectReader("risultati");
        m.setRisultati(decoder0.decode(reader, m.getRisultati()));
        reader = rootReader.newObjectReader("tema");
        m.setTema(decoder0.decode(reader, m.getTema()));
        reader = rootReader.newObjectReader("titoloProgetto");
        m.setTitoloProgetto(decoder0.decode(reader, m.getTitoloProgetto()));
        reader = rootReader.newObjectReader("version");
        m.setVersion(decoder0.decode(reader, m.getVersion()));
        return m;
    }
}