package project.meta;

//@javax.annotation.Generated(value = { "slim3-gen", "@VERSION@" }, date = "2012-06-21 15:55:16")
/** */
public final class PartnerMeta extends org.slim3.datastore.ModelMeta<project.model.Partner> {

    /** */
    public final org.slim3.datastore.StringUnindexedAttributeMeta<project.model.Partner> chiSiamo = new org.slim3.datastore.StringUnindexedAttributeMeta<project.model.Partner>(this, "chiSiamo", "chiSiamo");

    /** */
    public final org.slim3.datastore.StringAttributeMeta<project.model.Partner> email = new org.slim3.datastore.StringAttributeMeta<project.model.Partner>(this, "email", "email");

    /** */
    public final org.slim3.datastore.StringAttributeMeta<project.model.Partner> indirizzo = new org.slim3.datastore.StringAttributeMeta<project.model.Partner>(this, "indirizzo", "indirizzo");

    /** */
    public final org.slim3.datastore.CoreAttributeMeta<project.model.Partner, com.google.appengine.api.datastore.Key> key = new org.slim3.datastore.CoreAttributeMeta<project.model.Partner, com.google.appengine.api.datastore.Key>(this, "__key__", "key", com.google.appengine.api.datastore.Key.class);

    /** */
    public final org.slim3.datastore.StringAttributeMeta<project.model.Partner> nome = new org.slim3.datastore.StringAttributeMeta<project.model.Partner>(this, "nome", "nome");

    /** */
    public final org.slim3.datastore.StringAttributeMeta<project.model.Partner> sitoWeb = new org.slim3.datastore.StringAttributeMeta<project.model.Partner>(this, "sitoWeb", "sitoWeb");

    /** */
    public final org.slim3.datastore.StringAttributeMeta<project.model.Partner> telefono = new org.slim3.datastore.StringAttributeMeta<project.model.Partner>(this, "telefono", "telefono");

    /** */
    public final org.slim3.datastore.CoreAttributeMeta<project.model.Partner, java.lang.Long> version = new org.slim3.datastore.CoreAttributeMeta<project.model.Partner, java.lang.Long>(this, "version", "version", java.lang.Long.class);

    private static final PartnerMeta slim3_singleton = new PartnerMeta();

    /**
     * @return the singleton
     */
    public static PartnerMeta get() {
       return slim3_singleton;
    }

    /** */
    public PartnerMeta() {
        super("Partner", project.model.Partner.class);
    }

    @Override
    public project.model.Partner entityToModel(com.google.appengine.api.datastore.Entity entity) {
        project.model.Partner model = new project.model.Partner();
        model.setChiSiamo(textToString((com.google.appengine.api.datastore.Text) entity.getProperty("chiSiamo")));
        model.setEmail((java.lang.String) entity.getProperty("email"));
        model.setIndirizzo((java.lang.String) entity.getProperty("indirizzo"));
        model.setKey(entity.getKey());
        model.setNome((java.lang.String) entity.getProperty("nome"));
        model.setSitoWeb((java.lang.String) entity.getProperty("sitoWeb"));
        model.setTelefono((java.lang.String) entity.getProperty("telefono"));
        model.setVersion((java.lang.Long) entity.getProperty("version"));
        return model;
    }

    @Override
    public com.google.appengine.api.datastore.Entity modelToEntity(java.lang.Object model) {
        project.model.Partner m = (project.model.Partner) model;
        com.google.appengine.api.datastore.Entity entity = null;
        if (m.getKey() != null) {
            entity = new com.google.appengine.api.datastore.Entity(m.getKey());
        } else {
            entity = new com.google.appengine.api.datastore.Entity(kind);
        }
        entity.setUnindexedProperty("chiSiamo", stringToText(m.getChiSiamo()));
        entity.setProperty("email", m.getEmail());
        entity.setProperty("indirizzo", m.getIndirizzo());
        entity.setProperty("nome", m.getNome());
        entity.setProperty("sitoWeb", m.getSitoWeb());
        entity.setProperty("telefono", m.getTelefono());
        entity.setProperty("version", m.getVersion());
        entity.setProperty("slim3.schemaVersion", 1);
        return entity;
    }

    @Override
    protected com.google.appengine.api.datastore.Key getKey(Object model) {
        project.model.Partner m = (project.model.Partner) model;
        return m.getKey();
    }

    @Override
    protected void setKey(Object model, com.google.appengine.api.datastore.Key key) {
        validateKey(key);
        project.model.Partner m = (project.model.Partner) model;
        m.setKey(key);
    }

    @Override
    protected long getVersion(Object model) {
        project.model.Partner m = (project.model.Partner) model;
        return m.getVersion() != null ? m.getVersion().longValue() : 0L;
    }

    @Override
    protected void assignKeyToModelRefIfNecessary(com.google.appengine.api.datastore.AsyncDatastoreService ds, java.lang.Object model) {
    }

    @Override
    protected void incrementVersion(Object model) {
        project.model.Partner m = (project.model.Partner) model;
        long version = m.getVersion() != null ? m.getVersion().longValue() : 0L;
        m.setVersion(Long.valueOf(version + 1L));
    }

    @Override
    protected void prePut(Object model) {
    }

    @Override
    protected void postGet(Object model) {
    }

    @Override
    public String getSchemaVersionName() {
        return "slim3.schemaVersion";
    }

    @Override
    public String getClassHierarchyListName() {
        return "slim3.classHierarchyList";
    }

    @Override
    protected boolean isCipherProperty(String propertyName) {
        return false;
    }

    @Override
    protected void modelToJson(org.slim3.datastore.json.JsonWriter writer, java.lang.Object model, int maxDepth, int currentDepth) {
        project.model.Partner m = (project.model.Partner) model;
        writer.beginObject();
        org.slim3.datastore.json.Default encoder0 = new org.slim3.datastore.json.Default();
        if(m.getChiSiamo() != null){
            writer.setNextPropertyName("chiSiamo");
            encoder0.encode(writer, m.getChiSiamo());
        }
        if(m.getEmail() != null){
            writer.setNextPropertyName("email");
            encoder0.encode(writer, m.getEmail());
        }
        if(m.getIndirizzo() != null){
            writer.setNextPropertyName("indirizzo");
            encoder0.encode(writer, m.getIndirizzo());
        }
        if(m.getKey() != null){
            writer.setNextPropertyName("key");
            encoder0.encode(writer, m.getKey());
        }
        if(m.getNome() != null){
            writer.setNextPropertyName("nome");
            encoder0.encode(writer, m.getNome());
        }
        if(m.getSitoWeb() != null){
            writer.setNextPropertyName("sitoWeb");
            encoder0.encode(writer, m.getSitoWeb());
        }
        if(m.getTelefono() != null){
            writer.setNextPropertyName("telefono");
            encoder0.encode(writer, m.getTelefono());
        }
        if(m.getVersion() != null){
            writer.setNextPropertyName("version");
            encoder0.encode(writer, m.getVersion());
        }
        writer.endObject();
    }

    @Override
    protected project.model.Partner jsonToModel(org.slim3.datastore.json.JsonRootReader rootReader, int maxDepth, int currentDepth) {
        project.model.Partner m = new project.model.Partner();
        org.slim3.datastore.json.JsonReader reader = null;
        org.slim3.datastore.json.Default decoder0 = new org.slim3.datastore.json.Default();
        reader = rootReader.newObjectReader("chiSiamo");
        m.setChiSiamo(decoder0.decode(reader, m.getChiSiamo()));
        reader = rootReader.newObjectReader("email");
        m.setEmail(decoder0.decode(reader, m.getEmail()));
        reader = rootReader.newObjectReader("indirizzo");
        m.setIndirizzo(decoder0.decode(reader, m.getIndirizzo()));
        reader = rootReader.newObjectReader("key");
        m.setKey(decoder0.decode(reader, m.getKey()));
        reader = rootReader.newObjectReader("nome");
        m.setNome(decoder0.decode(reader, m.getNome()));
        reader = rootReader.newObjectReader("sitoWeb");
        m.setSitoWeb(decoder0.decode(reader, m.getSitoWeb()));
        reader = rootReader.newObjectReader("telefono");
        m.setTelefono(decoder0.decode(reader, m.getTelefono()));
        reader = rootReader.newObjectReader("version");
        m.setVersion(decoder0.decode(reader, m.getVersion()));
        return m;
    }
}